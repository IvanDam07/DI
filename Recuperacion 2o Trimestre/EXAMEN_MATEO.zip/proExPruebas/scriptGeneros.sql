insert into gender values (1,'fantasia');
insert into gender values (2,'ficcion');